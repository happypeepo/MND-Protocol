# `js-sys`

Raw bindings to JS global APIs for projects using `wasm-bindgen`. This crate is
handwritten and intended to work in *all* JS environments like browsers and
Node.js.

[Documentation](https://wasm-bindgen.github.io/wasm-bindgen/reference/types/js-sys.html)
