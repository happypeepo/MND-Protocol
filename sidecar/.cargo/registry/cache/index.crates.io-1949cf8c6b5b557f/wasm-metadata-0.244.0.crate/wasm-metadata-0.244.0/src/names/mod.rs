mod component;
mod module;

pub use component::ComponentNames;
pub use module::ModuleNames;
