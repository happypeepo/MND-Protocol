# CHANGELOG

## [0.1.0] - 2023-10-02

### Added

- Initial implementation

[Unreleased]: https://github.com/bluk/leb128fmt/compare/v0.1.0...HEAD
[0.2.0]: https://github.com/bluk/leb128fmt/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/bluk/leb128fmt/releases/tag/v0.1.0
