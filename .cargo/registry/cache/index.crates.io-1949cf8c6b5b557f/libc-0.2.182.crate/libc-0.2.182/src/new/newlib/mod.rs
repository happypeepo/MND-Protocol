//! Newlib libc.
// FIXME(newlib): link to headers needed.

pub(crate) mod unistd;
