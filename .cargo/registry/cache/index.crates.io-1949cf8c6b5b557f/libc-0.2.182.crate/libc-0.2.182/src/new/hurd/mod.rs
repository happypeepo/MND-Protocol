//! GNU Hurd libc.
// FIXME(hurd): link to headers needed.
