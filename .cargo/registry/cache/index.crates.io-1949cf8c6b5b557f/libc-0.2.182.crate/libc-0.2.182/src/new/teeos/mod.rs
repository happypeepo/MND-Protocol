//! Per the target docs, TEEOS uses part of musl as its libc.
// FIXME(teeos): link to headers needed.
