//! Windows Universal C Runtime.
//!
//! * Manual pages: <https://learn.microsoft.com/en-us/cpp/c-runtime-library/reference/crt-alphabetical-function-reference?view=msvc-170>
//! * UCRT information: <https://learn.microsoft.com/en-us/cpp/c-runtime-library/compatibility?view=msvc-170>
