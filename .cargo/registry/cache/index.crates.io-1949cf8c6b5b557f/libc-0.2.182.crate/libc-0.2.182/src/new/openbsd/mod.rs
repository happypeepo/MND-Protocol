//! OpenBSD libc.
//!
//! * Headers: <https://github.com/openbsd/src>
//! * Manual pages: <https://man.openbsd.org/>

pub(crate) mod sys;
pub(crate) mod unistd;
