//! RTEMS libc.
// FIXME(nuttx): link to headers needed.

pub(crate) mod unistd;
