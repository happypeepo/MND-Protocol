//! Cygwin libc.
//!
//! * Headers: <https://github.com/cygwin/cygwin/tree/main/winsup/cygwin/include>

pub(crate) mod unistd;
