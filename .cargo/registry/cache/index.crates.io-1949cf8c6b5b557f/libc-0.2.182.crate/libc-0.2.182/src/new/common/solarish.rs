//! Interfaces common in solaris-derived operating systems. This includes Solaris and Illumos.
