//! Haiku OS libc.
// FIXME(haiku): link to headers needed.

pub(crate) mod unistd;
