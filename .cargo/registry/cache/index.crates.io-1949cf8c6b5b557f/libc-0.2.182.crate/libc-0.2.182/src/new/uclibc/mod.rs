//! uClibc.
//!
//! * About: <https://uclibc.org/>
//! * Headers: <https://github.com/kraj/uClibc> (mirror)

pub(crate) mod pthread;
pub(crate) mod unistd;
