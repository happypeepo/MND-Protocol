//! L4re.
//!
//! * Headers: <https://github.com/kernkonzept/l4re-core/tree/master/libc/uclibc-ng>
