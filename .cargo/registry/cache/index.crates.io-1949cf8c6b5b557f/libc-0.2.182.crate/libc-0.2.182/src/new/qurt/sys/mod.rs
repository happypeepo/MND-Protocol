//! System headers (`sys/*`)

pub(crate) mod mman;
pub(crate) mod sched;
pub(crate) mod stat;
pub(crate) mod types;
