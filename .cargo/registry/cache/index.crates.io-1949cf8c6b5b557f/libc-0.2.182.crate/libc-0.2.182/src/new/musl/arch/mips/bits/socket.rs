use crate::prelude::*;

pub const SOCK_STREAM: c_int = 2;
pub const SOCK_DGRAM: c_int = 1;
